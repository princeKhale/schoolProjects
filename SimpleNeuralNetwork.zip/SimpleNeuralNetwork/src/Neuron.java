
public class Neuron {
	private float data;
	
	public Neuron(){
		setData(0);
	}
	
	public float getData() {
		return data;
	}

	public void setData(float data) {
		this.data = data;
	}
	
	

}
